package com.notesplus.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

val SORTS = listOf("UPDATED" to "По изменению", "CREATED" to "По созданию", "TITLE" to "По названию", "DATE" to "По дате плана")

fun kindIcon(k: String): ImageVector = when (k) { "CODE" -> Icons.Default.Code; "LIST" -> Icons.Default.CheckBox; else -> Icons.Default.Description }

@Composable
fun NotesScreen(vm: AppVm, onOpen: (String) -> Unit) {
    val d = vm.data
    val cs = MaterialTheme.colorScheme
    var query by rememberSaveable { mutableStateOf("") }
    var folder by rememberSaveable { mutableStateOf<String?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var addMenu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }

    val words = query.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val sort = d.settings.sort
    val cmp: Comparator<Note> = when (sort) {
        "TITLE" -> compareBy<Note> { it.title.lowercase() }
        "CREATED" -> compareByDescending<Note> { it.created }
        "DATE" -> compareBy<Note> { it.date ?: "9999" }
        else -> compareByDescending<Note> { it.updated }
    }
    val list = d.notes
        .filter { n -> (folder == null || n.folderId == folder) && words.all { w -> (n.title + "\n" + n.body).lowercase().contains(w) } }
        .sortedWith(compareByDescending<Note> { it.pinned }.then(cmp))

    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0), floatingActionButton = {
        Box {
            FloatingActionButton(onClick = { addMenu = true }) { Icon(Icons.Default.Add, "Новая") }
            DropdownMenu(expanded = addMenu, onDismissRequest = { addMenu = false }) {
                listOf("TEXT" to "Заметка", "LIST" to "Список / план", "CODE" to "Код").forEach { (k, l) ->
                    DropdownMenuItem(text = { Text(l) }, leadingIcon = { Icon(kindIcon(k), null) },
                        onClick = { addMenu = false; onOpen(vm.addNote(k, folder)) })
                }
            }
        }
    }) { p ->
        LazyColumn(Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = p.calculateTopPadding(), bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Title("Заметки", Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Сортировка") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            SORTS.forEach { (k, l) ->
                                DropdownMenuItem(text = { Text(l) },
                                    trailingIcon = { if (k == sort) Icon(Icons.Default.Check, null) },
                                    onClick = { vm.setSettings(d.settings.copy(sort = k)); sortMenu = false })
                            }
                        }
                    }
                }
            }
            item {
                TextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Поиск по заметкам") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null) } },
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = cs.surfaceVariant, unfocusedContainerColor = cs.surfaceVariant))
            }
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = folder == null, onClick = { folder = null }, label = { Text("Все (${d.notes.size})") })
                    d.folders.forEach { f ->
                        FilterChip(selected = folder == f.id, onClick = { folder = f.id }, label = { Text(f.name) },
                            leadingIcon = { Icon(Icons.Default.Folder, null, Modifier.size(18.dp)) })
                    }
                    AssistChip(onClick = { dlg = "new" }, label = { Text("Папка") },
                        leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(18.dp)) })
                }
            }
            d.folders.find { it.id == folder }?.let { f ->
                item {
                    Row {
                        TextButton(onClick = { dlg = "rename" }) { Text("Переименовать папку") }
                        TextButton(onClick = {
                            vm.edit { dd -> dd.copy(folders = dd.folders.filter { it.id != f.id },
                                notes = dd.notes.map { if (it.folderId == f.id) it.copy(folderId = null) else it }) }
                            folder = null
                        }) { Text("Удалить папку", color = cs.error) }
                    }
                }
            }
            if (list.isEmpty()) item {
                Text(if (words.isEmpty()) "Пока пусто. Нажмите «+», чтобы создать заметку." else "Ничего не найдено",
                    Modifier.padding(24.dp), color = cs.onSurfaceVariant)
            }
            items(list, key = { it.id }) { n -> NoteCard(vm, n, words, onOpen) }
        }
    }
    if (dlg == "new") NameDialog("Новая папка", "", { name -> val f = Folder(name = name); vm.edit { it.copy(folders = it.folders + f) }; folder = f.id }, { dlg = "" })
    if (dlg == "rename") d.folders.find { it.id == folder }?.let { f ->
        NameDialog("Название папки", f.name, { name -> vm.edit { dd -> dd.copy(folders = dd.folders.map { if (it.id == f.id) it.copy(name = name) else it }) } }, { dlg = "" })
    }
}

@Composable
fun NoteCard(vm: AppVm, n: Note, words: List<String>, onOpen: (String) -> Unit) {
    val d = vm.data
    val cs = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    val preview: String = when {
        n.kind == "LIST" -> {
            val it = n.body.lines().filter { l -> l.isNotBlank() }
            "${it.count { l -> l.startsWith("[x]") }} из ${it.size} выполнено"
        }
        words.isNotEmpty() && !n.body.lowercase().contains(words[0]) -> n.body.lineSequence().firstOrNull() ?: ""
        words.isNotEmpty() -> {
            val i = n.body.lowercase().indexOf(words[0])
            "…" + n.body.substring(maxOf(0, i - 20), minOf(n.body.length, i + 70)).replace('\n', ' ')
        }
        else -> n.body.trim().lineSequence().take(2).joinToString(" ")
    }
    val parent = n.parentId?.let { vm.note(it) }
    AppCard(Modifier.fillMaxWidth(), onClick = { onOpen(n.id) }) {
        Column(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(kindIcon(n.kind), null, Modifier.size(18.dp), tint = cs.primary)
                Spacer(Modifier.width(8.dp))
                Text(n.title.ifBlank { "Без названия" }, Modifier.weight(1f), fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                if (n.pinned) Icon(Icons.Default.PushPin, null, Modifier.size(16.dp), tint = cs.primary)
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(if (n.pinned) "Открепить" else "Закрепить") },
                            onClick = { vm.saveNote(n.copy(pinned = !n.pinned)); menu = false })
                        d.folders.forEach { f ->
                            DropdownMenuItem(text = { Text("В папку: ${f.name}") }, onClick = { vm.saveNote(n.copy(folderId = f.id)); menu = false })
                        }
                        if (n.folderId != null) DropdownMenuItem(text = { Text("Убрать из папки") }, onClick = { vm.saveNote(n.copy(folderId = null)); menu = false })
                        DropdownMenuItem(text = { Text("Удалить", color = cs.error) }, onClick = { vm.deleteNote(n.id); menu = false })
                    }
                }
            }
            if (preview.isNotBlank()) Text(preview, Modifier.padding(end = 12.dp), maxLines = 2, overflow = TextOverflow.Ellipsis,
                color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                fontFamily = if (n.kind == "CODE") FontFamily.Monospace else FontFamily.Default)
            val meta = listOfNotNull(
                DateFormat.getDateInstance(DateFormat.MEDIUM, ru).format(Date(n.updated)),
                d.folders.find { it.id == n.folderId }?.name?.let { "📁 $it" },
                parent?.let { "🔗 ${it.title.ifBlank { "Без названия" }}" },
                n.date?.let { "📅 " + java.time.LocalDate.parse(it).pretty() }
            ).joinToString("  ·  ")
            Text(meta, Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
    }
}
