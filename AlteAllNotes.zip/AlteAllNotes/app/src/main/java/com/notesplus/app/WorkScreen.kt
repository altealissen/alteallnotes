package com.notesplus.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun WorkScreen(vm: AppVm) {
    val d = vm.data
    val cs = MaterialTheme.colorScheme
    val cur = d.settings.currency
    var off by rememberSaveable { mutableIntStateOf(0) }
    var editJob by remember { mutableStateOf<Job?>(null) }
    var gigDlg by remember { mutableStateOf(false) }
    val ym = YearMonth.now().plusMonths(off.toLong())
    val stats = d.jobs.map { it to it.monthStat(ym) }
    val gigs = d.gigs.filter { it.date.startsWith(ym.toString()) }.sortedBy { it.date }
    val total = stats.sumOf { it.second.income } + gigs.sumOf { it.amount }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("Смены и доход") }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { off-- }) { Icon(Icons.Default.ChevronLeft, "Назад") }
                Text(ym.title(), Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { off++ }) { Icon(Icons.Default.ChevronRight, "Вперёд") }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Доход за месяц", color = cs.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
                    Text(total.money(cur), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = cs.primary)
                    Text("Смен: ${stats.sumOf { it.second.shifts }} · Оплачиваемых часов: ${stats.sumOf { it.second.hours }.h()}",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    stats.forEach { (j, s) -> Text("${j.name}: ${s.income.money(cur)} (${s.shifts} см.)", style = MaterialTheme.typography.bodyMedium) }
                    if (gigs.isNotEmpty()) Text("Подработки: ${gigs.sumOf { it.amount }.money(cur)}", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Работы", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                FilledTonalButton(onClick = { editJob = Job(name = if (d.jobs.isEmpty()) "Работа" else "Работа ${d.jobs.size + 1}") }) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Добавить")
                }
            }
        }
        if (d.jobs.isEmpty()) item { Text("Добавьте работу и выберите график, например 2/2 — смены на месяц рассчитаются автоматически.", color = cs.onSurfaceVariant) }
        items(d.jobs, key = { it.id }) { j ->
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(j.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        Text("График ${j.workDays}/${j.offDays} · ${j.timeRange()} · с ${LocalDate.parse(j.start).pretty()}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text((if (j.rateType == "DAILY") "${j.rate.money(cur)} за смену" else "${j.rate.money(cur)} в час") +
                            " · обед ${j.lunchMin} мин, " + (if (j.lunchPaid) "оплачивается" else "не оплачивается"),
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text("За смену: ${j.shiftIncome().money(cur)}", style = MaterialTheme.typography.bodyMedium, color = cs.primary)
                    }
                    IconButton(onClick = { editJob = j }) { Icon(Icons.Default.Edit, "Изменить") }
                    IconButton(onClick = { vm.edit { dd -> dd.copy(jobs = dd.jobs.filter { it.id != j.id }) } }) { Icon(Icons.Default.Delete, "Удалить") }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Подработки", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                FilledTonalButton(onClick = { gigDlg = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Добавить") }
            }
        }
        if (gigs.isEmpty()) item { Text("В этом месяце подработок нет", color = cs.onSurfaceVariant) }
        items(gigs, key = { it.id }) { g ->
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(g.title.ifBlank { "Подработка" }, fontWeight = FontWeight.Medium)
                        Text(LocalDate.parse(g.date).pretty(), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                    Text(g.amount.money(cur), fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = { vm.edit { dd -> dd.copy(gigs = dd.gigs.filter { it.id != g.id }) } }) { Icon(Icons.Default.Close, "Удалить") }
                }
            }
        }
    }
    editJob?.let { j ->
        JobDialog(j, cur, { nj ->
            vm.edit { dd -> if (dd.jobs.any { it.id == nj.id }) dd.copy(jobs = dd.jobs.map { if (it.id == nj.id) nj else it }) else dd.copy(jobs = dd.jobs + nj) }
        }, { editJob = null })
    }
    if (gigDlg) GigDialog(LocalDate.now().let { if (ym == YearMonth.from(it)) it else ym.atDay(1) }, cur, { g -> vm.edit { it.copy(gigs = it.gigs + g) } }, { gigDlg = false })
}

@Composable
fun JobDialog(init: Job, cur: String, onSave: (Job) -> Unit, onDismiss: () -> Unit) {
    fun fmt(x: Double) = x.toString().removeSuffix(".0")
    var name by remember { mutableStateOf(init.name) }
    var wd by remember { mutableStateOf(init.workDays.toString()) }
    var od by remember { mutableStateOf(init.offDays.toString()) }
    var start by remember { mutableStateOf(LocalDate.parse(init.start)) }
    var type by remember { mutableStateOf(init.rateType) }
    var rate by remember { mutableStateOf(if (init.rate == 0.0) "" else fmt(init.rate)) }
    var shift by remember { mutableStateOf(fmt(init.shiftHours)) }
    var st by remember { mutableStateOf(init.startTime) }
    var lunch by remember { mutableStateOf(init.lunchMin.toString()) }
    var paid by remember { mutableStateOf(init.lunchPaid) }
    var pick by remember { mutableStateOf(false) }
    val job = init.copy(
        name = name.ifBlank { "Работа" }, workDays = (wd.toIntOrNull() ?: 1).coerceAtLeast(1), offDays = (od.toIntOrNull() ?: 0).coerceAtLeast(0),
        start = start.toString(), rateType = type, rate = rate.num() ?: 0.0, shiftHours = shift.num() ?: 0.0,
        startTime = st, lunchMin = lunch.toIntOrNull() ?: 0, lunchPaid = paid
    )
    val num = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Работа") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название работы") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(2 to 2, 5 to 2, 1 to 3, 3 to 3, 4 to 4, 1 to 2).forEach { (a, b) ->
                        AssistChip(onClick = { wd = a.toString(); od = b.toString() }, label = { Text("$a/$b") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(wd, { wd = it }, Modifier.weight(1f), label = { Text("Рабочих") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(od, { od = it }, Modifier.weight(1f), label = { Text("Выходных") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                OutlinedButton(onClick = { pick = true }) { Text("Первая смена: ${start.pretty()}") }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "HOURLY", { type = "HOURLY" }, { Text("Почасовая") })
                    FilterChip(type == "DAILY", { type = "DAILY" }, { Text("За смену") })
                }
                OutlinedTextField(rate, { rate = it }, label = { Text(if (type == "HOURLY") "Ставка в час, $cur" else "Ставка за смену, $cur") }, singleLine = true, keyboardOptions = num)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(st, { st = it }, Modifier.weight(1f), label = { Text("Начало") }, singleLine = true)
                    OutlinedTextField(shift, { shift = it }, Modifier.weight(1f), label = { Text("Длина, ч") }, singleLine = true, keyboardOptions = num)
                }
                OutlinedTextField(lunch, { lunch = it }, label = { Text("Обед, минут") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Обед оплачивается", Modifier.weight(1f)); Switch(paid, { paid = it })
                }
                Text("Доход за смену: ${job.shiftIncome().money(cur)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(job); onDismiss() }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
    if (pick) DatePickDialog(start, { start = it }, { pick = false })
}
