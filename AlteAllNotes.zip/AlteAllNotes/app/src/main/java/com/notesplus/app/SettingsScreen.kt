package com.notesplus.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: AppVm) {
    val s = vm.data.settings
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Настройки")
        Text("Тема оформления", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        listOf("IOS" to ("Заметки iOS 27" to "Жёлтый акцент, сгруппированные карточки, большие заголовки"),
            "MATERIAL" to ("Material You" to "Цвета подстраиваются под обои (Android 12+)")).forEach { (k, v) ->
            AppCard(Modifier.fillMaxWidth(), onClick = { vm.setSettings(s.copy(theme = k)) }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.theme == k, onClick = { vm.setSettings(s.copy(theme = k)) })
                    Column { Text(v.first, fontWeight = FontWeight.Medium); Text(v.second, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
                }
            }
        }
        Text("Режим", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("SYSTEM" to "Системный", "LIGHT" to "Светлый", "DARK" to "Тёмный").forEach { (k, l) ->
                FilterChip(selected = s.dark == k, onClick = { vm.setSettings(s.copy(dark = k)) }, label = { Text(l) })
            }
        }
        Text("Валюта", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        OutlinedTextField(s.currency, { vm.setSettings(s.copy(currency = it.take(4))) }, singleLine = true, modifier = Modifier.width(120.dp))
        Text("Сортировка заметок", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            SORTS.forEach { (k, l) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.sort == k, onClick = { vm.setSettings(s.copy(sort = k)) }); Text(l)
                }
            }
        }
        Text("Alte All Notes 1.0 · данные хранятся на устройстве", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}
