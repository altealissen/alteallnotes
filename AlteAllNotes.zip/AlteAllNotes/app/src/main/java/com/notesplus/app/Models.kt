package com.notesplus.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.google.gson.Gson
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.util.UUID

fun uid(): String = UUID.randomUUID().toString()

data class Note(
    val id: String = uid(), val title: String = "", val body: String = "",
    val kind: String = "TEXT",            // TEXT | LIST | CODE
    val lang: String = "kotlin",
    val folderId: String? = null, val parentId: String? = null,  // parentId = цепочка
    val pinned: Boolean = false, val date: String? = null,
    val created: Long = System.currentTimeMillis(), val updated: Long = System.currentTimeMillis()
)

data class Folder(val id: String = uid(), val name: String = "")

data class Job(
    val id: String = uid(), val name: String = "Работа",
    val workDays: Int = 2, val offDays: Int = 2, val start: String = LocalDate.now().toString(),
    val rateType: String = "HOURLY",      // HOURLY | DAILY
    val rate: Double = 0.0, val shiftHours: Double = 12.0, val startTime: String = "08:00",
    val lunchMin: Int = 60, val lunchPaid: Boolean = false,
    val extra: List<String> = emptyList(), val skip: List<String> = emptyList()
)

data class Gig(val id: String = uid(), val date: String = LocalDate.now().toString(), val title: String = "", val amount: Double = 0.0)

data class Settings(val theme: String = "IOS", val dark: String = "SYSTEM", val currency: String = "₽", val sort: String = "UPDATED")

data class AppData(
    val notes: List<Note> = emptyList(), val folders: List<Folder> = emptyList(),
    val jobs: List<Job> = emptyList(), val gigs: List<Gig> = emptyList(), val settings: Settings = Settings()
)

// ---- расчёт смен и дохода ----
fun Job.works(d: LocalDate): Boolean {
    val s = d.toString()
    if (s in skip) return false
    if (s in extra) return true
    val diff = ChronoUnit.DAYS.between(LocalDate.parse(start), d)
    val cycle = workDays + offDays
    return diff >= 0 && cycle > 0 && diff % cycle < workDays
}
fun Job.paidHours(): Double = (shiftHours - if (lunchPaid) 0.0 else lunchMin / 60.0).coerceAtLeast(0.0)
fun Job.shiftIncome(): Double = if (rateType == "DAILY") rate else rate * paidHours()
fun Job.dayIncome(d: LocalDate): Double = if (works(d)) shiftIncome() else 0.0
fun Job.toggle(day: String): Job {
    val w = works(LocalDate.parse(day))
    return if (w) { if (day in extra) copy(extra = extra - day) else copy(skip = skip + day) }
    else { if (day in skip) copy(skip = skip - day) else copy(extra = extra + day) }
}
fun Job.timeRange(): String = try {
    val s = LocalTime.parse(startTime); "$s–${s.plusMinutes((shiftHours * 60).toLong())}"
} catch (e: Exception) { "${shiftHours.h()} ч" }

data class MStat(val shifts: Int, val hours: Double, val income: Double)
fun Job.monthStat(ym: YearMonth): MStat {
    var s = 0; var inc = 0.0
    for (i in 1..ym.lengthOfMonth()) { val dt = ym.atDay(i); if (works(dt)) { s++; inc += shiftIncome() } }
    return MStat(s, s * paidHours(), inc)
}

fun chainOf(all: List<Note>, id: String): List<Note> {
    var root = all.find { it.id == id } ?: return emptyList()
    val seen = mutableSetOf(root.id)
    while (root.parentId != null) {
        val p = all.find { it.id == root.parentId } ?: break
        if (!seen.add(p.id)) break
        root = p
    }
    val out = mutableListOf<Note>()
    fun walk(n: Note) {
        out.add(n)
        all.filter { it.parentId == n.id }.sortedBy { it.created }.forEach { c -> if (out.none { o -> o.id == c.id }) walk(c) }
    }
    walk(root)
    return out
}

class AppVm(app: Application) : AndroidViewModel(app) {
    private val file = File(app.filesDir, "data.json")
    private val gson = Gson()
    var data by mutableStateOf(load())
        private set

    private fun load(): AppData = try { gson.fromJson(file.readText(), AppData::class.java) ?: AppData() } catch (e: Exception) { AppData() }

    fun edit(f: (AppData) -> AppData) {
        data = f(data)
        try { file.writeText(gson.toJson(data)) } catch (_: Exception) { }
    }
    fun note(id: String?): Note? = data.notes.find { it.id == id }
    fun addNote(kind: String, folderId: String?, parentId: String? = null, date: String? = null): String {
        val n = Note(kind = kind, folderId = folderId, parentId = parentId, date = date)
        edit { it.copy(notes = it.notes + n) }
        return n.id
    }
    fun saveNote(n: Note) = edit { d -> d.copy(notes = d.notes.map { if (it.id == n.id) n.copy(updated = System.currentTimeMillis()) else it }) }
    fun deleteNote(id: String) = edit { d ->
        val p = d.notes.find { it.id == id }?.parentId
        d.copy(notes = d.notes.filter { it.id != id }.map { if (it.parentId == id) it.copy(parentId = p) else it })
    }
    fun setSettings(s: Settings) = edit { it.copy(settings = s) }
}
