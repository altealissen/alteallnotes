package com.notesplus.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: AppVm = viewModel()
            AppTheme(vm.data.settings) { Root(vm) }
        }
    }
}

@Composable
fun Root(vm: AppVm) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    val bg = MaterialTheme.colorScheme.background
    Surface(color = bg, modifier = Modifier.fillMaxSize()) {
        val o = open
        if (o != null) {
            EditorScreen(vm, o, onBack = { open = null }, onOpen = { open = it })
        } else {
            Scaffold(containerColor = bg, bottomBar = {
                NavigationBar {
                    listOf(
                        "Заметки" to Icons.Default.Description, "Календарь" to Icons.Default.CalendarMonth,
                        "Смены" to Icons.Default.Work, "Настройки" to Icons.Default.Settings
                    ).forEachIndexed { i, (l, ic) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) })
                    }
                }
            }) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> NotesScreen(vm) { open = it }
                        1 -> CalendarScreen(vm) { open = it }
                        2 -> WorkScreen(vm)
                        else -> SettingsScreen(vm)
                    }
                }
            }
        }
    }
}
