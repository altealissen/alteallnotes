package com.notesplus.app

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

val LocalIos = compositionLocalOf { true }
val ru: Locale = Locale.forLanguageTag("ru")
val WEEK = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

private val iosLight = lightColorScheme(
    primary = Color(0xFFE6A700), onPrimary = Color.Black,
    primaryContainer = Color(0xFFFFF1C2), onPrimaryContainer = Color(0xFF3D2E00),
    secondary = Color(0xFF34C759), tertiary = Color(0xFF007AFF),
    secondaryContainer = Color(0xFFFFF1C2), onSecondaryContainer = Color(0xFF3D2E00),
    background = Color(0xFFF2F2F7), onBackground = Color.Black,
    surface = Color.White, onSurface = Color.Black,
    surfaceVariant = Color(0xFFE5E5EA), onSurfaceVariant = Color(0xFF6C6C70),
    outline = Color(0xFFC6C6C8), outlineVariant = Color(0xFFE5E5EA),
    surfaceContainer = Color.White, surfaceContainerHigh = Color(0xFFE9E9EE), error = Color(0xFFFF3B30)
)
private val iosDark = darkColorScheme(
    primary = Color(0xFFFFD60A), onPrimary = Color.Black,
    primaryContainer = Color(0xFF4A3C00), onPrimaryContainer = Color(0xFFFFE88A),
    secondary = Color(0xFF30D158), tertiary = Color(0xFF0A84FF),
    secondaryContainer = Color(0xFF4A3C00), onSecondaryContainer = Color(0xFFFFE88A),
    background = Color.Black, onBackground = Color.White,
    surface = Color(0xFF1C1C1E), onSurface = Color.White,
    surfaceVariant = Color(0xFF2C2C2E), onSurfaceVariant = Color(0xFF98989F),
    outline = Color(0xFF48484A), outlineVariant = Color(0xFF38383A),
    surfaceContainer = Color(0xFF1C1C1E), surfaceContainerHigh = Color(0xFF2C2C2E), error = Color(0xFFFF453A)
)

@Composable
fun AppTheme(s: Settings, content: @Composable () -> Unit) {
    val dark = when (s.dark) { "LIGHT" -> false; "DARK" -> true; else -> isSystemInDarkTheme() }
    val ios = s.theme == "IOS"
    val ctx = LocalContext.current
    val scheme = when {
        ios -> if (dark) iosDark else iosLight
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        else -> if (dark) darkColorScheme() else lightColorScheme()
    }
    val shapes = if (ios) Shapes(
        small = RoundedCornerShape(10.dp), medium = RoundedCornerShape(14.dp),
        large = RoundedCornerShape(20.dp), extraLarge = RoundedCornerShape(28.dp)
    ) else Shapes()
    CompositionLocalProvider(LocalIos provides ios) {
        MaterialTheme(colorScheme = scheme, shapes = shapes, content = content)
    }
}

@Composable
fun Title(text: String, modifier: Modifier = Modifier) {
    val st = MaterialTheme.typography.headlineLarge
    Text(text, modifier.padding(top = 12.dp, bottom = 4.dp),
        style = if (LocalIos.current) st.copy(fontWeight = FontWeight.Bold, fontSize = 34.sp) else st)
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val c = CardDefaults.cardColors(containerColor = if (LocalIos.current) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceContainerHigh)
    if (onClick != null) Card(onClick = onClick, modifier = modifier, colors = c, content = content)
    else Card(modifier = modifier, colors = c, content = content)
}

@Composable
fun transparentFieldColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
)

@Composable
fun NameDialog(title: String, initial: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (t.isNotBlank()) { onOk(t.trim()); onDismiss() } }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickDialog(initial: LocalDate, onPick: (LocalDate) -> Unit, onDismiss: () -> Unit) {
    val st = rememberDatePickerState(initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
    DatePickerDialog(onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                onDismiss()
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }) { DatePicker(state = st) }
}

fun LocalDate.pretty(): String = format(DateTimeFormatter.ofPattern("d MMMM, EEE", ru))
fun YearMonth.title(): String = month.getDisplayName(TextStyle.FULL_STANDALONE, ru).replaceFirstChar { it.uppercase() } + " " + year
fun String.num(): Double? = replace(',', '.').toDoubleOrNull()
fun Double.h(): String = if (this % 1.0 == 0.0) toInt().toString() else String.format(Locale.US, "%.1f", this)
fun Double.money(c: String): String {
    val s = if (this % 1.0 == 0.0) String.format(Locale.US, "%,.0f", this) else String.format(Locale.US, "%,.2f", this)
    return s.replace(',', ' ') + " " + c
}
