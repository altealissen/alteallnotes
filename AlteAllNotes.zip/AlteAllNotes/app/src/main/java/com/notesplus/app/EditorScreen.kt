package com.notesplus.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate

data class LItem(val text: String = "", val done: Boolean = false)

fun parseItems(b: String): List<LItem> = b.lines().filter { it.isNotBlank() }.map {
    when {
        it.startsWith("[x] ") -> LItem(it.drop(4), true)
        it.startsWith("[ ] ") -> LItem(it.drop(4))
        else -> LItem(it)
    }
}

val LANGS = listOf("kotlin", "java", "python", "js", "c", "sql", "sh", "json", "plain")
private val KW = mapOf(
    "kotlin" to "fun val var class object interface if else when for while return import package is in as null true false this super override private public internal data sealed enum open abstract suspend try catch finally throw break continue companion by lateinit const",
    "java" to "public private protected class interface extends implements new static final void int long double float boolean char if else for while return import package null true false this super try catch finally throw throws break continue switch case default enum abstract",
    "python" to "def class if elif else for while return import from as None True False self in is not and or try except finally with lambda pass break continue yield raise global",
    "js" to "function const let var if else for while return import export from class new this null undefined true false async await try catch finally throw typeof switch case break default extends",
    "c" to "int char float double void long short unsigned if else for while return struct typedef include define static const sizeof switch case break continue NULL enum",
    "sql" to "select from where insert into values update set delete create table join left right inner on group by order limit and or not null as distinct having",
    "sh" to "if then else fi for do done while case esac function echo export cd return in",
    "json" to "true false null"
).mapValues { it.value.split(" ").toSet() }

fun highlight(src: String, lang: String, dark: Boolean): AnnotatedString {
    val cComment = if (dark) Color(0xFF8E8E93) else Color(0xFF7D7D82)
    val cStr = if (dark) Color(0xFF8BD17C) else Color(0xFF2E7D32)
    val cNum = if (dark) Color(0xFFFFA559) else Color(0xFFC25E00)
    val cKw = if (dark) Color(0xFFFF7AB2) else Color(0xFFB0236E)
    val cType = if (dark) Color(0xFF6CB6FF) else Color(0xFF0B5FC4)
    val cm = when (lang) {
        "python", "sh" -> "#[^\\n]*"
        "sql" -> "--[^\\n]*"
        "json", "plain" -> "(?!)"
        else -> "//[^\\n]*|/\\*[\\s\\S]*?\\*/"
    }
    val str = if (lang == "plain") "(?!)" else "\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'"
    val re = Regex("($cm)|($str)|(\\b\\d+(?:\\.\\d+)?\\b)|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)")
    val kw = KW[lang] ?: emptySet()
    return buildAnnotatedString {
        append(src)
        re.findAll(src).forEach { m ->
            val s = m.range.first; val e = m.range.last + 1
            val c = when {
                m.groups[1] != null -> cComment
                m.groups[2] != null -> cStr
                m.groups[3] != null -> cNum
                else -> {
                    val w = m.value
                    if ((if (lang == "sql") w.lowercase() else w) in kw) cKw
                    else if (lang != "plain" && w[0].isUpperCase()) cType else null
                }
            }
            if (c != null) addStyle(SpanStyle(color = c), s, e)
        }
    }
}

private class Hl(val lang: String, val dark: Boolean) : VisualTransformation {
    override fun filter(text: AnnotatedString) = TransformedText(highlight(text.text, lang, dark), OffsetMapping.Identity)
}

private fun codeChange(old: TextFieldValue, new: TextFieldValue, lang: String): TextFieldValue {
    val p = new.selection.start
    if (new.text.length == old.text.length + 1 && new.selection.collapsed && p > 0 && new.text[p - 1] == '\n') {
        val line = new.text.substring(0, p - 1).substringAfterLast('\n')
        var indent = line.takeWhile { it == ' ' || it == '\t' }
        val t = line.trimEnd()
        if (t.endsWith("{") || t.endsWith("(") || t.endsWith("[") || (lang == "python" && t.endsWith(":"))) indent += "  "
        return new.copy(text = new.text.substring(0, p) + indent + new.text.substring(p), selection = TextRange(p + indent.length))
    }
    return new
}

private fun insertAt(v: TextFieldValue, s: String, caret: Int): TextFieldValue {
    val sel = v.selection
    return v.copy(text = v.text.replaceRange(sel.min, sel.max, s), selection = TextRange(sel.min + caret))
}

@Composable
fun CodeEditor(value: TextFieldValue, onChange: (TextFieldValue) -> Unit, lang: String, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 21.sp)
    val lines = value.text.count { it == '\n' } + 1
    Row(modifier.verticalScroll(rememberScrollState()).defaultMinSize(minHeight = 500.dp).padding(vertical = 8.dp)) {
        Text((1..lines).joinToString("\n"), Modifier.padding(horizontal = 8.dp).width(32.dp),
            style = mono.copy(color = cs.onSurfaceVariant, textAlign = TextAlign.End))
        BasicTextField(value = value, onValueChange = { onChange(codeChange(value, it, lang)) },
            textStyle = mono.copy(color = cs.onSurface), cursorBrush = SolidColor(cs.primary), softWrap = false,
            visualTransformation = Hl(lang, dark),
            modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(end = 16.dp))
    }
}

private val KEYS = listOf(
    Triple("⇥", "  ", 2), Triple("{ }", "{}", 1), Triple("( )", "()", 1), Triple("[ ]", "[]", 1),
    Triple("\" \"", "\"\"", 1), Triple(";", ";", 1), Triple("=", "=", 1), Triple(":", ":", 1),
    Triple("<", "<", 1), Triple(">", ">", 1), Triple("/", "/", 1), Triple("!", "!", 1), Triple("&", "&", 1), Triple("|", "|", 1)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AppVm, id: String, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val note = vm.note(id)
    if (note == null) { LaunchedEffect(Unit) { onBack() }; return }
    val kind = note.kind
    val cs = MaterialTheme.colorScheme
    var title by remember(id) { mutableStateOf(note.title) }
    var body by remember(id) { mutableStateOf(TextFieldValue(if (kind == "LIST") "" else note.body)) }
    var lang by remember(id) { mutableStateOf(note.lang) }
    var pinned by remember(id) { mutableStateOf(note.pinned) }
    var date by remember(id) { mutableStateOf(note.date) }
    val items = remember(id) { mutableStateListOf<LItem>().also { if (kind == "LIST") it.addAll(parseItems(note.body)) } }
    var focusIdx by remember(id) { mutableIntStateOf(-1) }
    var showDate by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    var langMenu by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    fun curBody() = if (kind == "LIST") items.joinToString("\n") { (if (it.done) "[x] " else "[ ] ") + it.text } else body.text
    fun isBlank() = title.isBlank() && (if (kind == "LIST") items.all { it.text.isBlank() } else body.text.isBlank())
    fun save() {
        val cur = vm.note(id) ?: return
        val n = cur.copy(title = title, body = curBody(), lang = lang, pinned = pinned, date = date)
        if (n != cur) vm.saveNote(n)
    }
    fun finish() { if (isBlank()) vm.deleteNote(id) else save() }

    LaunchedEffect(title, body.text, lang, pinned, date, items.toList()) { delay(400); save() }
    BackHandler { finish(); onBack() }

    Scaffold(containerColor = cs.background, topBar = {
        TopAppBar(title = {}, colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
            navigationIcon = { IconButton(onClick = { finish(); onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад") } },
            actions = {
                if (kind == "CODE") {
                    Box {
                        TextButton(onClick = { langMenu = true }) { Text(lang) }
                        DropdownMenu(expanded = langMenu, onDismissRequest = { langMenu = false }) {
                            LANGS.forEach { l -> DropdownMenuItem(text = { Text(l) }, onClick = { lang = l; langMenu = false }) }
                        }
                    }
                    IconButton(onClick = { clip.setText(AnnotatedString(body.text)) }) { Icon(Icons.Default.ContentCopy, "Копировать") }
                }
                IconButton(onClick = { showDate = true }) { Icon(Icons.Default.Event, "Дата") }
                IconButton(onClick = { pinned = !pinned }) {
                    Icon(Icons.Default.PushPin, "Закрепить", tint = if (pinned) cs.primary else LocalContentColor.current)
                }
                IconButton(onClick = { confirmDel = true }) { Icon(Icons.Default.Delete, "Удалить") }
            })
    }) { pad ->
        Column(Modifier.padding(pad).imePadding().fillMaxSize()) {
            TextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Заголовок", style = MaterialTheme.typography.headlineSmall) },
                textStyle = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                colors = transparentFieldColors())
            date?.let { ds ->
                Row(Modifier.padding(horizontal = 16.dp)) {
                    AssistChip(onClick = { showDate = true }, label = { Text(LocalDate.parse(ds).pretty()) },
                        leadingIcon = { Icon(Icons.Default.Event, null, Modifier.size(18.dp)) },
                        trailingIcon = { Icon(Icons.Default.Close, null, Modifier.size(18.dp).clickable { date = null }) })
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (kind) {
                    "LIST" -> LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(items) { i, li ->
                            val fr = remember { FocusRequester() }
                            LaunchedEffect(focusIdx) { if (focusIdx == i) { fr.requestFocus(); focusIdx = -1 } }
                            Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = li.done, onCheckedChange = { c -> items[i] = li.copy(done = c) })
                                TextField(value = li.text, onValueChange = { t -> items[i] = li.copy(text = t) },
                                    modifier = Modifier.weight(1f).focusRequester(fr), singleLine = true,
                                    placeholder = { Text("Пункт") },
                                    textStyle = if (li.done) LocalTextStyle.current.copy(textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant) else LocalTextStyle.current,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                                    keyboardActions = KeyboardActions(onNext = { items.add(i + 1, LItem()); focusIdx = i + 1 }),
                                    colors = transparentFieldColors())
                                IconButton(onClick = { items.removeAt(i) }) { Icon(Icons.Default.Close, "Удалить пункт") }
                            }
                        }
                        item {
                            Row(Modifier.padding(horizontal = 8.dp)) {
                                TextButton(onClick = { items.add(LItem()); focusIdx = items.size - 1 }) {
                                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Пункт")
                                }
                                TextButton(onClick = { items.removeAll { it.done } }) { Text("Убрать выполненные") }
                            }
                        }
                    }
                    "CODE" -> CodeEditor(body, { body = it }, lang, Modifier.fillMaxSize())
                    else -> TextField(value = body, onValueChange = { body = it }, modifier = Modifier.fillMaxSize(),
                        placeholder = { Text("Начните писать…") }, colors = transparentFieldColors())
                }
            }
            if (kind == "CODE") {
                Row(Modifier.fillMaxWidth().background(cs.surfaceVariant).horizontalScroll(rememberScrollState())) {
                    KEYS.forEach { (l, t, c) ->
                        TextButton(onClick = { body = insertAt(body, t, c) }, contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier.height(40.dp)) { Text(l, fontFamily = FontFamily.Monospace, color = cs.onSurface) }
                    }
                }
            }
            val chain = chainOf(vm.data.notes, id)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Link, "Цепочка", tint = cs.onSurfaceVariant)
                if (chain.size > 1) chain.forEachIndexed { i, n ->
                    FilterChip(selected = n.id == id, onClick = { finish(); onOpen(n.id) },
                        label = { Text("${i + 1}. ${n.title.ifBlank { "Без названия" }}", maxLines = 1) })
                }
                AssistChip(onClick = {
                    val c = vm.addNote("TEXT", note.folderId, parentId = id)
                    finish(); onOpen(c)
                }, label = { Text("Следующая в цепочке") }, leadingIcon = { Icon(Icons.Default.Add, null, Modifier.size(18.dp)) })
            }
        }
    }
    if (showDate) DatePickDialog(date?.let { LocalDate.parse(it) } ?: LocalDate.now(), { date = it.toString() }, { showDate = false })
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false }, title = { Text("Удалить заметку?") },
        confirmButton = { TextButton(onClick = { vm.deleteNote(id); confirmDel = false; onBack() }) { Text("Удалить", color = cs.error) } },
        dismissButton = { TextButton(onClick = { confirmDel = false }) { Text("Отмена") } })
}
