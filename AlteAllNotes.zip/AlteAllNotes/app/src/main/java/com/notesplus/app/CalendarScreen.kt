package com.notesplus.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun CalendarScreen(vm: AppVm, onOpen: (String) -> Unit) {
    val d = vm.data
    val cs = MaterialTheme.colorScheme
    val cur = d.settings.currency
    var off by rememberSaveable { mutableIntStateOf(0) }
    var sel by rememberSaveable { mutableStateOf(LocalDate.now().toString()) }
    var gigDlg by remember { mutableStateOf(false) }
    val ym = YearMonth.now().plusMonths(off.toLong())
    val today = LocalDate.now()
    val selD = LocalDate.parse(sel)
    val dayGigs = d.gigs.filter { it.date == sel }
    val dayNotes = d.notes.filter { it.date == sel }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Title("Календарь") }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { off-- }) { Icon(Icons.Default.ChevronLeft, "Назад") }
                        Text(ym.title(), Modifier.weight(1f), textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { off++ }) { Icon(Icons.Default.ChevronRight, "Вперёд") }
                    }
                    Row { WEEK.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant) } }
                    val lead = ym.atDay(1).dayOfWeek.value - 1
                    val rows = (lead + ym.lengthOfMonth() + 6) / 7
                    for (r in 0 until rows) Row {
                        for (c in 0..6) {
                            val n = r * 7 + c - lead + 1
                            if (n in 1..ym.lengthOfMonth()) {
                                val day = ym.atDay(n); val ds = day.toString()
                                DayCell(day, ds == sel, day == today, d.jobs.count { it.works(day) },
                                    d.notes.any { it.date == ds }, d.gigs.any { it.date == ds }, Modifier.weight(1f)) { sel = ds }
                            } else Spacer(Modifier.weight(1f))
                        }
                    }
                    Text("● смена   ● заметка   ● подработка", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
                }
            }
        }
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(selD.pretty(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (d.jobs.isEmpty()) Text("Добавьте работу на вкладке «Смены», и график появится здесь", color = cs.onSurfaceVariant)
                    d.jobs.forEach { j ->
                        val w = j.works(selD)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(j.name, fontWeight = FontWeight.Medium)
                                Text(if (w) "${j.timeRange()} · ${j.dayIncome(selD).money(cur)}" else "Выходной",
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                            }
                            TextButton(onClick = { vm.edit { dd -> dd.copy(jobs = dd.jobs.map { if (it.id == j.id) it.toggle(sel) else it }) } }) {
                                Text(if (w) "Сделать выходным" else "Сделать рабочим")
                            }
                        }
                    }
                    dayGigs.forEach { g ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("💼 ${g.title.ifBlank { "Подработка" }} · ${g.amount.money(cur)}", Modifier.weight(1f))
                            IconButton(onClick = { vm.edit { dd -> dd.copy(gigs = dd.gigs.filter { it.id != g.id }) } }) { Icon(Icons.Default.Close, "Удалить") }
                        }
                    }
                    val total = d.jobs.sumOf { it.dayIncome(selD) } + dayGigs.sumOf { it.amount }
                    if (total > 0) Text("Доход за день: ${total.money(cur)}", fontWeight = FontWeight.Bold, color = cs.primary)
                    dayNotes.forEach { n ->
                        Row(Modifier.fillMaxWidth().clickable { onOpen(n.id) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(kindIcon(n.kind), null, Modifier.size(18.dp), tint = cs.primary)
                            Spacer(Modifier.width(8.dp))
                            Text(n.title.ifBlank { "Без названия" })
                        }
                    }
                    Row {
                        TextButton(onClick = { onOpen(vm.addNote("TEXT", null, null, sel)) }) { Text("+ Заметка") }
                        TextButton(onClick = { onOpen(vm.addNote("LIST", null, null, sel)) }) { Text("+ План") }
                        TextButton(onClick = { gigDlg = true }) { Text("+ Подработка") }
                    }
                }
            }
        }
    }
    if (gigDlg) GigDialog(selD, cur, { g -> vm.edit { it.copy(gigs = it.gigs + g) } }, { gigDlg = false })
}

@Composable
fun DayCell(day: LocalDate, selected: Boolean, today: Boolean, shifts: Int, hasNote: Boolean, hasGig: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(modifier.padding(2.dp).clip(RoundedCornerShape(12.dp))
        .background(if (selected) cs.primaryContainer else Color.Transparent).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(if (today) cs.primary else Color.Transparent), contentAlignment = Alignment.Center) {
            Text("${day.dayOfMonth}", color = if (today) cs.onPrimary else cs.onSurface, style = MaterialTheme.typography.bodyMedium)
        }
        Row(Modifier.padding(top = 3.dp).height(5.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(minOf(shifts, 2)) { Dot(cs.primary) }
            if (hasNote) Dot(cs.tertiary)
            if (hasGig) Dot(cs.secondary)
        }
    }
}

@Composable
private fun Dot(c: Color) = Box(Modifier.size(5.dp).clip(CircleShape).background(c))

@Composable
fun GigDialog(initDate: LocalDate, cur: String, onSave: (Gig) -> Unit, onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(initDate) }
    var pick by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Подработка") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text("Сумма, $cur") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedButton(onClick = { pick = true }) { Text(date.pretty()) }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(Gig(date = date.toString(), title = title.trim(), amount = amount.num() ?: 0.0)); onDismiss() }) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
    if (pick) DatePickDialog(date, { date = it }, { pick = false })
}
